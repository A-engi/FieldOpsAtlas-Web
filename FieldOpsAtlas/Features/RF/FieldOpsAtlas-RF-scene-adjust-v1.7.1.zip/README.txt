FieldOps Atlas RF scene adjustment v1.7.1

Replace only:
- FieldOpsAtlas/Features/RF/3d-render.js
- FieldOpsAtlas/Features/RF/3D Graphics/river-scene.js
- FieldOpsAtlas/Features/RF/3D Graphics/transmitter-gold-full.js
- FieldOpsAtlas/Features/RF/3D Graphics/transmitter-gold-quarter.js
- FieldOpsAtlas/Features/RF/index.html

Changes:
- River scene zoom tightened so the mountain sides meet the graph edges.
- Around the 110-degree side orbit the camera lowers, moves closer and shifts the scene down.
- The foreground transmitter feet sit close to the lower graph edge while the rear transmitter and tip remain visible above it.
- Mounted river-scene transmitters receive a 24-degree Y pre-rotation in river-scene.js before each mountain rotation is composed, so the flat face is presented at the intended side alignment.
- The pre-rotation is scene-owned; no orientation is baked into either transmitter object. The standalone transmitter scene remains flat-front.
- Removed the three cluttered middle service decks, handrails and projecting panel antennas from both transmitter assets.
- Preserved the tapered lattice, feet, upper cage, top mast and beacon.
- Preserved the current 1.7.0 selected-path graph-builder and 1.2.0 path-builder wiring in index.html.
- Mountain files are unchanged.
