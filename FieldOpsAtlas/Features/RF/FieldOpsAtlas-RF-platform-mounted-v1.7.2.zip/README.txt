FieldOps Atlas RF v1.7.2 — transmitter platform mounting correction

Replace:
- FieldOpsAtlas/Features/RF/3D Graphics/river-scene.js
- FieldOpsAtlas/Features/RF/index.html

Changes:
- Transmitter X/Z footprint now fits inside each mountain's actual square platform.
- Transmitter Y scale is calculated independently so the mast remains slightly above the mountain peak.
- Mountain A and Mountain B use their own platform centre, size and top height.
- Mountain B receives a slightly higher tip clearance so the rear mast remains visible above Mountain A.
- The 24-degree flat/upright scene pre-rotation remains in river-scene.js.
- No mountain, transmitter geometry or renderer files changed.
