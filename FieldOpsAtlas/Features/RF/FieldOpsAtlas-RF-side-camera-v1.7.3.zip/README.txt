FieldOps Atlas RF side-camera update v1.7.3

Replace the five files in the included repository structure.

Changes:
- Front view remains effectively unchanged.
- Side motion eases in gradually after the orbit threshold.
- Camera moves about 12% closer in the strongest side view.
- Camera transitions from looking down to almost level/slightly upward.
- Scene rolls gradually so the floor no longer stays visually flat.
- White-front/A side receives stronger downward framing so foreground transmitter feet approach the graph edge.
- Black-front/B side uses a slightly lighter downward shift.
- Mountain B transmitter clearance is exactly tripled from 0.85 to 2.55.
- Transmitter feet remain attached to each platform; only vertical scaling changes.
- Includes the cleaned transmitter object files required by river-scene.js.

Validation:
- All JavaScript and index inline scripts passed node --check.
- All eight scene-selector variants loaded in Chromium with a real WebGL context.
- Front, transition and both side directions rendered without page or console errors.
