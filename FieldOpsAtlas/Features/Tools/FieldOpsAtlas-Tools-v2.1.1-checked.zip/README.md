# FieldOps Atlas Tools v2.1.1

Upload the contents of `FieldOpsAtlas/Features/Tools/` into the matching repository folder.

## Included

- Front Tools page with quick converter
- Modular calculator library
- Universal converter with 77 conversion families / 453 units
- Coax identifier
- 151 calculators
- Hide/show/reorder and local usage tracking
- No replacement icon folder; use the repository's existing icons
- Repeatable calculator test suite in `tests/calculator-checker.js`
- Full audit notes in `CALCULATOR-AUDIT.md`

## Calculator verification

The v2.1.1 calculator code was checked with:

- 151/151 calculators covered
- 155 known-value test cases
- 216 numerical assertions
- 14 edge and validation checks
- JavaScript syntax validation on every calculator file

The checker can be rerun from the extracted bundle with:

```bash
node tests/calculator-checker.js
```

## Upload order

1. `shared/`
2. `calculators/`
3. `converters/`
4. `coax-calculator.html`
5. `converter.html`
6. `calculator-library.html`
7. `index.html` last

## Calculator summaries

Each of the 151 calculator entries lists one or two calculations or outputs beneath its title. These labels are searchable and stored in `calculators/calculator-capabilities.js` and `manifest.json`.
