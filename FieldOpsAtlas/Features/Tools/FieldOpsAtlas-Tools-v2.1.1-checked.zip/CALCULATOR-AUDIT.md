# Calculator audit — FieldOps Atlas Tools v2.1.1

## Scope

The audit loaded the actual calculator JavaScript files from this bundle and executed the registered `compute` function for every calculator.

| Check | Result |
|---|---:|
| Registered calculators | 151 |
| Calculators with known-value coverage | 151 |
| Known-value cases | 155 |
| Numerical assertions | 216 |
| Additional edge/validation checks | 14 |
| Missing calculator coverage | 0 |
| Failures after corrections | 0 |

## Corrections made after testing v2.1.0

1. **ADC resolution** now uses `Vref / 2^N` for ideal LSB size rather than `Vref / (2^N - 1)`.
2. **DAC voltage** now uses `code × Vref / 2^N`; maximum code is explicitly described as full-scale minus one LSB.
3. Blank numeric fields are rejected instead of being silently interpreted as zero.
4. Average and standard-deviation lists reject non-numeric entries instead of silently discarding them.
5. Signed power values now retain sensible W/kW/mW/µW/nW formatting.
6. Single- and three-phase current calculations reject power factor above 1.
7. Motor current rejects efficiency above 100% and power factor above 1.
8. Battery and UPS runtime reject efficiency above 100%.
9. DMM loading error now works at a zero-volt source without producing an undefined percentage.
10. Zero demand, zero average load and zero running speed are accepted where physically meaningful.
11. Cable and fibre loss tools reject negative lengths, losses and component counts.

## Test coverage

The known-value suite covers all categories:

- General: 16
- RF: 35
- Electronics: 34
- Electrical: 29
- Broadcast: 13
- Instruments: 10
- Cable: 7
- Sensors: 7

Reverse-direction checks are included for dBm/watts, dBW/watts, dB ratios and related bidirectional tools. Edge tests cover empty inputs, invalid power factors and efficiencies, negative loss data, zero-voltage DMM loading, signed power formatting, zero demand and stopped-motor slip.

## Engineering limitations retained intentionally

Several tools are engineering estimates rather than substitutes for manufacturer data, approved design software or statutory test procedures. Examples include radio horizon, dish beamwidth, battery runtime, motor full-load current, linear PT100/PT1000 conversion and the -174 dBm/Hz receiver-noise approximation. Their formulas are suitable for quick field estimates when the stated assumptions are understood.

## Reference basis

The audit cross-checked representative formula families against primary or manufacturer sources, including:

- Keysight documentation for dBm/watts and VSWR/return-loss relationships
- Tektronix oscilloscope bandwidth/rise-time guidance
- Analog Devices ideal ADC/DAC LSB definitions
- Ofcom UK DTT centre-frequency relationship `Fc = 8n + 306`

The automated checker is included so later edits can be retested against the same known values.
